A Pen created at CodePen.io. You can find this one at https://codepen.io/PavelDoGreat/pen/zdWzEL.

 works on mobile browsers too

references:

http://developer.download.nvidia.com/books/HTML/gpugems/gpugems_ch38.html

https://github.com/mharrys/fluids-2d

https://github.com/haxiomic/GPU-Fluid-Experiments
