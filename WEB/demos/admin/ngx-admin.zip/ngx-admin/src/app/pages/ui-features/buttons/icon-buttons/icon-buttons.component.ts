import { Component } from '@angular/core';

@Component({
  selector: 'ngx-icon-buttons',
  styleUrls: ['./icon-buttons.component.scss'],
  templateUrl: './icon-buttons.component.html',
})
export class IconButtonsComponent {
}
